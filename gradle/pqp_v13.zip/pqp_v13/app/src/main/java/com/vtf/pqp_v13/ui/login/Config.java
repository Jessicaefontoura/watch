package com.vtf.pqp_v13.ui.login;

public class Config {
    public static final String EMAIL = "Email";
    public static final String PASSWORD = "Senha";
    public static final String LOGIN_SUCCESS = "sucesso";
    public static final String SHARED_PREF_NAME = "login";
    public static final String EMAIL_SHARED_PREF = "email";
    public static final String LOGGEDIN_SHARED_PREF = "logado";

    public static final Object LOGIN_URL = "";
}
