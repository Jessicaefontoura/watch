package com.vtf.pqp_v13.ui.login;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.vtf.pqp_v13.MainActivity;
import com.vtf.pqp_v13.R;
import com.vtf.pqp_v13.ui.principal.TelaPrincipal;

import org.json.JSONException;
import org.json.JSONObject;


public class LoginActivity {
    private static final String email = "admin";
    private static final String password = "admin";

    private String Email;
    private String Password;

    public String getEmail(){
         return Email;
    }
    public void setEmail(String email){
        Email = email;
    }
    public String getPassword(){
        return password;
    }
    public void setPassword(String password){
        Password = password;
    }

    public boolean ValidarUsuario(){
        if (Email.equals("")){
            return false;
        }
        else if (Password.equals("")){
            return false;
        }
        else if (!Email.equals(email) || !Password.equals(password)){
            return false;
        }
        else{
            return true;
        }

    }




}



