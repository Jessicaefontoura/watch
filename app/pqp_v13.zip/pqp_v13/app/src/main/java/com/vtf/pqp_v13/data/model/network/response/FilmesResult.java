package com.vtf.pqp_v13.data.model.network.response;

import java.util.List;
import com.squareup.moshi.Json;

public class FilmesResult {

    @Json(name = "results")
    private final List<FilmeResponse> resultadoFilmes;

    public FilmesResult(List<FilmeResponse> resultadoFilmes) {
        this.resultadoFilmes = resultadoFilmes;
    }

    public List<FilmeResponse> getResultadoFilmes(){
        return resultadoFilmes;
    }
}
