package com.vtf.pqp_v13;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tela_login);
        //if (savedInstanceState == null) {
            //getSupportFragmentManager().beginTransaction()
                   // .replace(R.id.container, newInstance())
                   // .commitNow();
        //}
    }


}